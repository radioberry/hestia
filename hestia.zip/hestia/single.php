<?php
/**
 * The template for displaying all single posts and attachments.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

get_header(); ?>
			<div id="primary" class="page-header header-filter header-small" data-parallax="active" style="background-image: url('<?php echo hestia_featured_header(); ?>');">
				<div class="container">
					<div class="row">
						<div class="col-md-8 col-md-offset-2 text-center">
							<?php single_post_title( '<h1 class="title">', '</h1>' ); ?>
							<h4 class="author"><?php printf( __( 'Published by <a href="%2$s"><b>%1$s</b></a> on <time>%3$s</time>', 'hestia' ), esc_html( hestia_get_author( 'display_name' ) ), esc_url( get_author_posts_url( hestia_get_author( 'ID' ) ) ), esc_html( get_the_time( get_option( 'date_format' ) ) ) ); ?></h4>
						</div>
					</div>
				</div>
			</div>
		</header>
		<div class="<?php echo hestia_layout(); ?>">
			<div class="blog-post">
				<div class="container">
					<?php
					if ( have_posts() ) :
						while ( have_posts() ) : the_post();
							get_template_part( 'template-parts/content', 'single' );
							if ( comments_open() || get_comments_number() ) :
								comments_template();
							endif;
						endwhile;
					else :
						get_template_part( 'template-parts/content', 'none' );
					endif;
					?>
				</div>
			</div>
		</div>
		<?php do_action( 'hestia_blog_related_posts' ); ?>
		<div class="<?php echo hestia_layout(); ?>">
<?php get_footer(); ?>
