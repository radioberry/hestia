<?php
/**
 * Hooks for WooCommerce which only needs to be used when WooCommerce is active.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0.2
 */

/**
 * Layout for the main content of shop page
 *
 * @see  hestia_woocommerce_before_main_content()
 * @see  hestia_woocommerce_after_main_content()
 */
remove_action( 'woocommerce_sidebar', 				    'woocommerce_get_sidebar', 		                10 );  /* Remove the sidebar */
add_action( 'woocommerce_before_main_content', 		'hestia_woocommerce_before_main_content', 		10 );
add_action( 'woocommerce_after_main_content', 		'hestia_woocommerce_after_main_content', 		50 );


/**
 * Layout for each product content on the shop page
 *
 * @see hestia_woocommerce_template_loop_product_thumbnail()
 * @see hestia_woocommerce_before_shop_loop_item()
 * @see hestia_woocommerce_after_shop_loop_item()
 * @see hestia_woocommerce_template_loop_product_title()
 */
// remove_action(  'woocommerce_before_shop_loop_item_title',        'woocommerce_show_product_loop_sale_flash',             10 );
remove_action( 'woocommerce_before_shop_loop_item_title', 	    'woocommerce_template_loop_product_thumbnail',          10 ); /* Remove the default thumbnail */
add_action( 'woocommerce_before_shop_loop_item_title', 	    'hestia_woocommerce_template_loop_product_thumbnail',   10 );

remove_action( 'woocommerce_before_shop_loop_item',            'woocommerce_template_loop_product_link_open', 10 ); /* Remove unused link */
add_action( 'woocommerce_before_shop_loop_item', 		    'hestia_woocommerce_before_shop_loop_item', 10 );

remove_action( 'woocommerce_after_shop_loop_item',             'woocommerce_template_loop_product_link_close', 5 ); /* Remove unused link */
add_action( 'woocommerce_after_shop_loop_item', 		    'hestia_woocommerce_after_shop_loop_item', 20 );

remove_action( 'woocommerce_after_shop_loop_item',             'woocommerce_template_loop_add_to_cart' ); /* Remove default add to cart on single product */
remove_action( 'woocommerce_shop_loop_item_title',             'woocommerce_template_loop_product_title', 10 ); /* Remove default product title on single product */
remove_action( 'woocommerce_after_shop_loop_item_title',       'woocommerce_template_loop_rating', 5 ); /* Remove default rating on single product */
remove_action( 'woocommerce_after_shop_loop_item_title',       'woocommerce_template_loop_price', 10 ); /* Remove default price on single product */
add_action( 'woocommerce_shop_loop_item_title',             'hestia_woocommerce_template_loop_product_title', 10 );

