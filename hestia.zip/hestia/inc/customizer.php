<?php
/**
 * Customizer functionality for the theme.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Add JS to enable live previews.
 *
 * @since Hestia 1.0
 */
function hestia_customizer_live_preview() {
	wp_enqueue_script( 'hestia_customizer_preview', get_template_directory_uri() . '/assets/js/customizer.js', array( 'jquery', 'customize-preview' ), '', true );
}
add_action( 'customize_preview_init', 'hestia_customizer_live_preview' );


/**
 * Register and enqueue customizer script
 *
 * @since Hestia 1.0
 */
function hestia_customizer_controls() {
	wp_enqueue_script( 'hestia_customize_controls', get_template_directory_uri() . '/assets/js/customizer-controls.js', array( 'jquery', 'customize-controls' ), false, true );
}
add_action( 'customize_controls_enqueue_scripts', 'hestia_customizer_controls' );

if ( ! function_exists( 'hestia_sanitize_checkbox' ) ) :
	/**
	 * Sanitize checkbox output.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_sanitize_checkbox( $input ) {
		if ( $input ) {
			$output = '1';
		} else {
			$output = false;
		}
		return $output;
	}
endif;

/**
 * Register panels for Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_customize_register( $wp_customize ) {

	$wp_customize->add_panel( 'hestia_appearance_settings', array(
		'priority' => 25,
		'title' => __( 'Appearance Settings', 'hestia' ),
	));

	$wp_customize->add_panel( 'hestia_frontpage_sections', array(
		'priority' => 30,
		'title' => __( 'Frontpage Sections', 'hestia' ),
		'description' => __( 'Drag and drop panels to change sections order.','hestia' ),
	));

	$wp_customize->add_panel( 'hestia_blog_settings', array(
		'priority' => 35,
		'title' => __( 'Blog Settings', 'hestia' ),
	));

	$wp_customize->get_section( 'header_image' )->panel = 'hestia_appearance_settings';
	$wp_customize->get_section( 'background_image' )->panel = 'hestia_appearance_settings';
	$wp_customize->get_setting( 'blogname' )->transport = 'postMessage';
	$wp_customize->get_setting( 'blogdescription' )->transport = 'postMessage';
	$wp_customize->get_setting( 'custom_logo' )->transport = 'postMessage';

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'custom_logo', array(
			'selector' => '.navbar-brand',
			'settings' => 'custom_logo',
			'render_callback' => 'hestia_custom_logo_callback',
		));
	}

}

add_action( 'customize_register', 'hestia_customize_register' );

/**
 * Custom logo callback function.
 *
 * @return string
 */
function hestia_custom_logo_callback() {
	if ( get_theme_mod( 'custom_logo' ) ) {
		$logo = wp_get_attachment_image_src( get_theme_mod( 'custom_logo' ) , 'full' );
		$logo = '<img src="' . esc_url( $logo[0] ) . '">';
	} else {
		if ( is_front_page() ) {
			$logo = '<h1>' . get_bloginfo( 'name' ) . '</h1>';
		} else {
			$logo = '<p>' . get_bloginfo( 'name' ) . '</p>';
		}
	}
	return $logo;
}


