<?php
/**
 * Contact section for the homepage.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

if ( ! function_exists( 'hestia_contact_section' ) ) :
	/**
	 * Contact section content.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_contact_section() {
		$hestia_contact_title = get_theme_mod( 'hestia_contact_title', __( 'Get in Touch', 'hestia' ) );
		$hestia_contact_subtitle = get_theme_mod( 'hestia_contact_subtitle', __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ) );
		$hestia_contact_area_title = get_theme_mod( 'hestia_contact_area_title', __( 'Contact Us', 'hestia' ) );
		?>
		<section class="contactus section-image" id="hestia_contact" style="background-image: url('<?php echo get_theme_mod( 'hestia_contact_background', get_template_directory_uri() . '/assets/img/contact.jpg' ); ?>')">
			<div class="container">
				<div class="row">
					<div class="col-md-5">
					<?php if ( ! empty( $hestia_contact_title ) || is_customize_preview() ) : ?>
						<h2 class="title"><?php echo esc_html( $hestia_contact_title ); ?></h2>
					<?php endif; ?>
					<?php if ( ! empty( $hestia_contact_subtitle ) || is_customize_preview() ) : ?>
						<h5 class="description"><?php echo esc_html( $hestia_contact_subtitle ); ?></h5>
					<?php endif; ?>
					<?php
						$hestia_contact_content = get_theme_mod( 'hestia_contact_content', json_encode( array(
			            	array(
								'icon_value' => 'fa-map-marker',
								'title' => __( 'Find us at the office', 'hestia' ),
								'text' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
								'id' => 'customizer_repeater_56d7ea7f40f56',
							),
							array(
								'icon_value' => 'fa-mobile',
								'title' => __( 'Give us a ring', 'hestia' ),
								'text' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
								'id' => 'customizer_repeater_56d7ea7f40f66',
							),
						)) );
						if ( ! empty( $hestia_contact_content ) ) :
							$hestia_contact_content = json_decode( $hestia_contact_content );
							foreach ( $hestia_contact_content as $contact_item ) :
					?>
						<div class="info info-horizontal">
						<?php if ( ! empty( $contact_item->icon_value ) ) : ?>
							<div class="icon icon-primary">
								<i class="fa <?php echo esc_html( $contact_item->icon_value ); ?>"></i>
							</div>
						<?php endif; ?>
							<div class="description">
							<?php if ( ! empty( $contact_item->title ) ) : ?>
								<h4 class="info-title"><?php echo esc_html( $contact_item->title ); ?></h4>
							<?php endif; ?>
							<?php if ( ! empty( $contact_item->text ) ) : ?>
								<p><?php echo esc_html( $contact_item->text ); ?></p>
							<?php endif; ?>
							</div>
						</div>
					<?php
							endforeach;
						endif;
					?>
					</div>
					<?php if ( defined( 'PIRATE_FORMS_VERSION' ) ) : ?>
					<div class="col-md-5 col-md-offset-2">
						<div class="card card-contact">
						<?php if ( ! empty( $hestia_contact_area_title ) || is_customize_preview() ) : ?>
							<div class="header header-raised header-primary text-center">
								<h4 class="card-title"><?php echo esc_html( $hestia_contact_area_title ); ?></h4>
							</div>
						<?php endif; ?>
							<div class="content">
								<?php echo do_shortcode( '[pirate_forms]' ) ?>
							</div>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>
		</section>
		<?php
	}
	$section_priority = apply_filters( 'hestia_section_priority', 55, 'hestia_contact' );
	add_action( 'hestia_sections', 'hestia_contact_section', $section_priority );
endif;
