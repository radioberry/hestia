<?php
/**
 * About section for the homepage.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

if ( ! function_exists( 'hestia_about_section' ) ) :
	/**
	 * About section content.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_about_section() {
		$hestia_about_title = get_theme_mod( 'hestia_about_title', __( 'Who are we', 'hestia' ) );
		$hestia_about_subtitle = get_theme_mod( 'hestia_about_subtitle', __( 'The story that made us who we are', 'hestia' ) );
		$hestia_about_content = get_theme_mod( 'hestia_about_content', __( 'Ideate integrate food-truck agile ideate thinker-maker-doer user story intuitive hacker integrate workflow Steve Jobs. Steve Jobs pair programming food-truck big data long shadow SpaceTeam agile agile affordances. User centered design food-truck experiential minimum viable product human-centered design prototype viral quantitative vs. qualitative.', 'hestia' ) );
		$hestia_about_image = get_theme_mod( 'hestia_about_image', get_template_directory_uri() . '/assets/img/about.png' );
		$hestia_about_background = get_theme_mod( 'hestia_about_background', get_template_directory_uri() . '/assets/img/contact.jpg' );

		if ( isset( $hestia_about_background ) && ! empty( $hestia_about_background ) ) {
			$class_to_add = 'section-image';
		}
		?>
		<section class="about <?php if ( ! empty( $class_to_add ) ) { echo $class_to_add;} ?>" id="hestia_about" <?php if ( ! empty( $hestia_about_background ) ) { echo 'style="background-image: url(\'' . esc_url( $hestia_about_background ) . '\')"'; }?>>
			<div class="container">
				<div class="row">
				</div>
				<div class="row">
				<?php if ( ! empty( $hestia_about_content ) || is_customize_preview() ) : ?>
					<?php if ( ! empty( $hestia_about_image ) ) : ?>
					<div class="col-md-4 text-area">
					<?php else : ?>
					<div class="col-md-12 text-area">
					<?php endif; ?>
						<?php if ( ! empty( $hestia_about_title ) || is_customize_preview() ) : ?>
							<h3 class="title"><?php echo esc_html( $hestia_about_title ); ?></h3>
						<?php endif; ?>
						<?php if ( ! empty( $hestia_about_subtitle ) || is_customize_preview() ) : ?>
							<h6 class="description"><?php echo esc_html( $hestia_about_subtitle ); ?></h6>
						<?php endif;
						echo '<div class="about-content">' . wp_kses_post( $hestia_about_content ) . '</div>'; ?>
					</div>
				<?php endif; ?>
				<?php if ( ! empty( $hestia_about_image ) ) : ?>
					<?php if ( ! empty( $hestia_about_content ) && ! empty( $hestia_about_title ) && ! empty( $hestia_about_subtitle ) ) : ?>
					<div class="col-md-7 col-md-offset-1 media-area">
					<?php else : ?>
					<div class="col-md-12 media-area">
					<?php endif; ?>
						<div class="iframe-container">
							<img src="<?php echo esc_url( $hestia_about_image ); ?>"/>
						</div>
					</div>
				<?php endif; ?>
				<?php if ( empty( $hestia_about_image ) && is_customize_preview() ) : ?>
					<div class="col-md-6 media-area customizer-hidden">
						<div class="iframe-container">
							<img src="<?php echo esc_url( $hestia_about_image ); ?>"/>
						</div>
					</div>
				<?php endif; ?>
				</div>
			</div>
		</section>
		<?php
	}
	$section_priority = apply_filters( 'hestia_section_priority', 15, 'hestia_about' );
	add_action( 'hestia_sections', 'hestia_about_section', $section_priority );
endif;
