<?php
/**
 * Testimonials section for the homepage.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

if ( ! function_exists( 'hestia_testimonials_section' ) ) :
	/**
	 * Testimonials section content.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_testimonials_section() {
		$hestia_testimonials_title = get_theme_mod( 'hestia_testimonials_title', __( 'What clients say', 'hestia' ) );
		$hestia_testimonials_subtitle = get_theme_mod( 'hestia_testimonials_subtitle', __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ) );
		?>
		<section class="testimonials" id="hestia_testimonials">
			<div class="container">
				<div class="row">
					<div class="col-md-8 col-md-offset-2 text-center">
					<?php if ( ! empty( $hestia_testimonials_title ) || is_customize_preview() ) : ?>
						<h2 class="title"><?php echo esc_html( $hestia_testimonials_title ); ?></h2>
					<?php endif; ?>
					<?php if ( ! empty( $hestia_testimonials_subtitle ) || is_customize_preview() ) : ?>
						<h5 class="description"><?php echo esc_html( $hestia_testimonials_subtitle ); ?></h5>
					<?php endif; ?>
					</div>
				</div>
				<div class="row">
				<?php
					$hestia_testimonials_content = get_theme_mod( 'hestia_testimonials_content', json_encode( array(
						 array(
							'image_url' => get_template_directory_uri() . '/assets/img/1.jpg',
							'title' => __( 'The Empire', 'hestia' ),
							'subtitle' => __( 'Dark Lord', 'hestia' ),
							'text' => __( '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."', 'hestia' ),
							'id' => 'customizer_repeater_56d7ea7f40d56',
						),
						array(
							'image_url' => get_template_directory_uri() . '/assets/img/2.jpg',
							'title' => __( 'Kylo Ren', 'hestia' ),
							'subtitle' => __( 'The First Order', 'hestia' ),
							'text' => __( '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."', 'hestia' ),
							'id' => 'customizer_repeater_56d7ea7f40d66',
						),
					   	array(
							'image_url' => get_template_directory_uri() . '/assets/img/3.jpg',
							'title' => __( 'Sidious', 'hestia' ),
							'subtitle' => __( 'The Empire', 'hestia' ),
							'text' => __( '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."', 'hestia' ),
							'id' => 'customizer_repeater_56d7ea7f40d66',
						),
					)) );
					if ( ! empty( $hestia_testimonials_content ) ) :
						$hestia_testimonials_content = json_decode( $hestia_testimonials_content );
						foreach ( $hestia_testimonials_content as $testimonial_item ) :
				?>
					<div class="col-md-4">
						<div class="card card-testimonial card-plain">
						<?php if ( ! empty( $testimonial_item->image_url ) ) : ?>
							<div class="card-avatar">
							<?php if ( ! empty( $testimonial_item->link ) ) : ?>
								<a href="<?php echo esc_url( $testimonial_item->link ); ?>">
							<?php endif; ?>
									<img class="img flipInTestimonial animated-testimonial" src="<?php echo esc_url( $testimonial_item->image_url ); ?>" <?php if ( ! empty( $testimonial_item->title ) ) : ?> title="<?php echo esc_attr( $testimonial_item->title ); ?>" <?php endif; ?> />
							<?php if ( ! empty( $testimonial_item->link ) ) : ?>
								</a>
							<?php endif; ?>
							</div>
						<?php endif; ?>
							<div class="content">
							<?php if ( ! empty( $testimonial_item->title ) ) : ?>
								<h4 class="card-title"><?php echo esc_html( $testimonial_item->title ); ?></h4>
							<?php endif; ?>
							<?php if ( ! empty( $testimonial_item->subtitle ) ) : ?>
								<h6 class="category text-muted"><?php echo esc_html( $testimonial_item->subtitle ); ?></h6>
							<?php endif; ?>
							<?php if ( ! empty( $testimonial_item->text ) ) : ?>
								<h5 class="card-description"><?php echo esc_html( $testimonial_item->text ); ?></h5>
							<?php endif; ?>
							</div>
						</div>
					</div>
				<?php
						endforeach;
					endif;
				?>
				</div>
			</div>
		</section>
		<?php
	}

	$section_priority = apply_filters( 'hestia_section_priority', 40, 'hestia_testimonials' );
	add_action( 'hestia_sections', 'hestia_testimonials_section', $section_priority );
endif;
