<?php
/**
 * Team section for the homepage.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

if ( ! function_exists( 'hestia_authors_blog_section' ) ) :
	/**
	 * Team section content.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_authors_blog_section() {
		$hestia_authors_on_blog = get_theme_mod( 'hestia_authors_on_blog', '0' );
		$hestia_team_content = get_theme_mod( 'hestia_team_content' );
		if ( ! empty( $hestia_team_content ) && ($hestia_authors_on_blog[0] !== '0' ) ) {

			$hestia_team_content = json_decode( $hestia_team_content ); ?>

			<section class="authors-on-blog section-image" id="authors-on-blog" style="background-image: url('<?php echo get_theme_mod( 'hestia_authors_on_blog_background', get_template_directory_uri() . '/assets/img/header.jpg' ); ?>');">
				<div class="container">
					<div class="row">

						<?php

						foreach ( $hestia_team_content as $team_item ) {
							foreach ( $hestia_authors_on_blog as $hestia_author_on_blog ) {
								if ( $team_item->id == $hestia_author_on_blog ) { ?>

									<div class="col-md-6">
										<div class="card card-profile card-plain">
											<div class="col-md-5">
												<div class="card-image">
													<?php if ( ! empty( $team_item->image_url ) ) : ?>
														<?php if ( ! empty( $team_item->link ) ) : ?>
															<a href="<?php echo esc_url( $team_item->link ); ?>">
														<?php endif; ?>
														<img class="img" src="<?php echo esc_url( $team_item->image_url ); ?>" <?php if ( ! empty( $team_item->title ) ) : ?> title="<?php echo esc_attr( $team_item->title ); ?>" <?php endif; ?> />
														<?php if ( ! empty( $team_item->link ) ) : ?>
															</a>
														<?php endif; ?>
													<?php endif; ?>
												</div>
											</div>
											<div class="col-md-7">
												<div class="content">
													<?php if ( ! empty( $team_item->title ) ) : ?>
														<h4 class="card-title"><?php echo esc_html( $team_item->title ); ?></h4>
													<?php endif; ?>
													<?php if ( ! empty( $team_item->subtitle ) ) : ?>
														<h6 class="category text-muted"><?php echo esc_html( $team_item->subtitle ); ?></h6>
													<?php endif; ?>
													<?php if ( ! empty( $team_item->text ) ) : ?>
														<p class="card-description"><?php echo esc_html( $team_item->text ); ?></p>
													<?php endif;

if ( ! empty( $team_item->social_repeater ) ) :
	$icons = html_entity_decode( $team_item->social_repeater );
	$icons_decoded = json_decode( $icons, true );
	if ( ! empty( $icons_decoded ) ) :
		?>
		<div class="footer">
			<?php foreach ( $icons_decoded as $value ) : ?>
																	<?php if ( ! empty( $value['icon'] ) ) : ?>
																		<a href="<?php echo esc_url( $value['link'] ); ?>" class="btn btn-just-icon btn-simple btn-white">
																			<i class="fa <?php echo esc_attr( $value['icon'] ); ?>"></i>
																		</a>
																	<?php endif; ?>
																<?php endforeach; ?>
															</div>
															<?php
														endif;
													endif;
													?>
												</div>
											</div>
										</div>
									</div>

									<?php

								}
							}
						}

						?>

			</section>

		<?php }

	}

	add_action( 'hestia_after_archive_content', 'hestia_authors_blog_section', 10 );

endif;

