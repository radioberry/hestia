<?php
/**
 * Pricing section for the homepage.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

if ( ! function_exists( 'hestia_pricing_section' ) ) :
	/**
	 * Pricing section content.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_pricing_section() {
		$hestia_pricing_title = get_theme_mod( 'hestia_pricing_title', __( 'Choose a plan for your next project', 'hestia' ) );
		$hestia_pricing_subtitle = get_theme_mod( 'hestia_pricing_subtitle', __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ) );
		$hestia_pricing_table_one_title = get_theme_mod( 'hestia_pricing_table_one_title', __( 'Basic Package', 'hestia' ) );
		$hestia_pricing_table_one_price = get_theme_mod( 'hestia_pricing_table_one_price', __( '<small>$</small>0', 'hestia' ) );
		$hestia_pricing_table_one_features = get_theme_mod( 'hestia_pricing_table_one_features', array(
			__( '<b>1</b> Domain', 'hestia' ),
			__( '<b>1GB</b> Storage', 'hestia' ),
			__( '<b>100GB</b> Bandwidth', 'hestia' ),
			__( '<b>2</b> Databases', 'hestia' ),
		));
		$hestia_pricing_table_one_link = get_theme_mod( 'hestia_pricing_table_one_link', __( '#', 'hestia' ) );
		$hestia_pricing_table_one_text = get_theme_mod( 'hestia_pricing_table_one_text', __( 'Free Download', 'hestia' ) );
		$hestia_pricing_table_two_title = get_theme_mod( 'hestia_pricing_table_two_title', __( 'Premium Package', 'hestia' ) );
		$hestia_pricing_table_two_price = get_theme_mod( 'hestia_pricing_table_two_price', __( '<small>$</small>49', 'hestia' ) );
		$hestia_pricing_table_two_features = get_theme_mod( 'hestia_pricing_table_two_features', array(
			__( '<b>5</b> Domain', 'hestia' ),
			__( '<b>Unlimited</b> Storage', 'hestia' ),
			__( '<b>Unlimited</b> Bandwidth', 'hestia' ),
			__( '<b>Unlimited</b> Databases', 'hestia' ),
		));
		$hestia_pricing_table_two_link = get_theme_mod( 'hestia_pricing_table_two_link', __( '#', 'hestia' ) );
		$hestia_pricing_table_two_text = get_theme_mod( 'hestia_pricing_table_two_text', __( 'Order Now', 'hestia' ) );
		?>
		<section class="pricing section-gray" id="hestia_pricing">
			<div class="container">
				<div class="row">
					<div class="col-md-4">
					<?php if ( ! empty( $hestia_pricing_title ) || is_customize_preview() ) : ?>
						<h2 class="title"><?php echo esc_html( $hestia_pricing_title ); ?></h2>
					<?php endif; ?>
					<?php if ( ! empty( $hestia_pricing_subtitle ) || is_customize_preview() ) : ?>
						<p class="text-gray"><?php echo esc_html( $hestia_pricing_subtitle ); ?></p>
					<?php endif; ?>
					</div>
					<div class="col-md-7 col-md-offset-1">
						<div class="col-md-6">
							<div class="card card-pricing card-raised">
								<div class="content">
								<?php if ( ! empty( $hestia_pricing_table_one_title ) || is_customize_preview() ) : ?>
									<h6 class="category"><?php echo esc_html( $hestia_pricing_table_one_title ); ?></h6>
								<?php endif; ?>
								<?php if ( ! empty( $hestia_pricing_table_one_price ) || is_customize_preview() ) : ?>
									<h3 class="card-title"><?php echo wp_kses_post( $hestia_pricing_table_one_price ); ?></h3>
								<?php endif; ?>
									<ul>
									<?php if ( ! empty( $hestia_pricing_table_one_features ) ) : ?>
									<?php foreach ( $hestia_pricing_table_one_features as $feature ) : ?>
										<li><?php echo wp_kses_post( $feature );?></li>
									<?php endforeach; ?>
									<?php endif; ?>
									</ul>
								<?php if ( ( ! empty( $hestia_pricing_table_one_link ) && ! empty( $hestia_pricing_table_one_text ) ) || is_customize_preview() ) : ?>
									<a href="<?php echo esc_url( $hestia_pricing_table_one_link ); ?>" class="btn btn-primary btn-round"><?php echo esc_html( $hestia_pricing_table_one_text ); ?></a> 
								<?php endif; ?>
								</div>
							</div>
						</div><div class="col-md-6">
							<div class="card card-pricing card-plain">
								<div class="content">
								<?php if ( ! empty( $hestia_pricing_table_two_title ) || is_customize_preview() ) : ?>
									<h6 class="category"><?php echo esc_html( $hestia_pricing_table_two_title ); ?></h6>
								<?php endif; ?>
								<?php if ( ! empty( $hestia_pricing_table_two_price ) || is_customize_preview() ) : ?>
									<h3 class="card-title"><?php echo wp_kses_post( $hestia_pricing_table_two_price ); ?></h3>
								<?php endif; ?>
								<?php if ( ! empty( $hestia_pricing_table_two_features ) ) : ?>
									<ul>
									<?php foreach ( $hestia_pricing_table_two_features as $feature ) : ?>
										<li><?php echo wp_kses_post( $feature );?></li>
									<?php endforeach; ?>
									</ul>
								<?php endif; ?>
								<?php if ( ( ! empty( $hestia_pricing_table_two_link ) && ! empty( $hestia_pricing_table_two_text ) ) || is_customize_preview() ) : ?>
									<a href="<?php echo esc_url( $hestia_pricing_table_two_link ); ?>" class="btn btn-primary btn-round"><?php echo esc_html( $hestia_pricing_table_two_text ); ?></a> 
								<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<?php
	}
	$section_priority = apply_filters( 'hestia_section_priority', 35, 'hestia_pricing' );
	add_action( 'hestia_sections', 'hestia_pricing_section', $section_priority );
endif;
