<?php
/**
 * Portfolio section for the homepage.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */


if ( class_exists( 'Jetpack' ) ) {

	if ( Jetpack::is_module_active( 'custom-content-types' ) ) {

		if ( ! function_exists( 'hestia_portfolio_section' ) ) :
			/**
			 * Portfolio section content.
			 *
			 * @since Hestia 1.0
			 */
			function hestia_portfolio_section() {
				$hestia_portfolio_title = get_theme_mod( 'hestia_portfolio_title', __( 'Portfolio', 'hestia' ) );
				$hestia_portfolio_subtitle = get_theme_mod( 'hestia_portfolio_subtitle', __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ) );
				$hestia_portfolio_items = get_theme_mod( 'hestia_portfolio_items', 3 );
				$hestia_portfolio_boxes_type = get_theme_mod( 'hestia_portfolio_boxes_type', false );
				?>
				<section class="work" id="hestia_portfolio">
					<div class="container">
						<div class="row">
							<div class="col-md-8 col-md-offset-2 text-center">
								<?php if ( ! empty( $hestia_portfolio_title ) || is_customize_preview() ) : ?>
									<h2 class="title"><?php echo esc_html( $hestia_portfolio_title ); ?></h2>
								<?php endif; ?>
								<?php if ( ! empty( $hestia_portfolio_subtitle ) || is_customize_preview() ) : ?>
									<h5 class="description"><?php echo esc_html( $hestia_portfolio_subtitle ); ?></h5>
								<?php endif; ?>
							</div>
						</div>
						<?php if ( post_type_exists( 'jetpack-portfolio' ) ) { ?>
							<div class="row">
								<?php if ( ! empty( $hestia_portfolio_items ) ) : ?>
									<?php $port = new WP_Query( array( 'post_type' => 'jetpack-portfolio', 'posts_per_page' => $hestia_portfolio_items ) ); ?>
								<?php else : ?>
									<?php $port = new WP_Query( array( 'post_type' => 'jetpack-portfolio', 'posts_per_page' => 3 ) ); ?>
								<?php endif; ?>
								<?php
								if ( $port->have_posts() ) :

									$portfolio_counter = 1;

									while ( $port->have_posts() ) : $port->the_post();

										if ( ! empty( $hestia_portfolio_boxes_type ) && ( $hestia_portfolio_boxes_type == true ) ) {
											if ( ( $portfolio_counter % 4 == 0 ) || ( $portfolio_counter % 5 == 0 ) ) {
												$portfolio_class_to_add = 'col-md-6';
											} elseif ( $portfolio_counter > 5 ) {
												$portfolio_counter = 1;
												$portfolio_class_to_add = 'col-md-4';
											} else {
												$portfolio_class_to_add = 'col-md-4';
											}
											$portfolio_counter++;
										} else {
											$portfolio_class_to_add = 'col-md-4';
										}

										?>

										<div class="<?php echo $portfolio_class_to_add; ?> portfolio-item portfolioAnimation animated">
											<div class="card card-background card-raised" style="background-image: url('<?php the_post_thumbnail_url( 'hestia-portfolio' ); ?>')">
												<a href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>">
													<div class="content">
														<?php $hestia_categories = get_the_terms( $post->ID , 'jetpack-portfolio-type' ); ?>
														<?php if ( ! empty( $hestia_categories ) ) : ?>
															<label class="label label-primary"><?php echo esc_html( $hestia_categories[0]->name ); ?></label>
														<?php endif; ?>
														<?php the_title( '<h4 class="card-title">', '</h4>' ); ?>
													</div>
												</a>
											</div>
										</div>
										<?php
									endwhile;
								endif;
								?>
							</div>
						<?php } ?>
					</div>
				</section>
				<?php
			}

		endif;
		$section_priority = apply_filters( 'hestia_section_priority', 25, 'hestia_portfolio' );
		add_action( 'hestia_sections', 'hestia_portfolio_section', $section_priority );

	}
}
