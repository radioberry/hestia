<?php
/**
 * Customizer functionality for the Blog settings panel.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Hook controls for Blog Settings section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_blog_settings_customize_register( $wp_customize ) {

	/**
	 * A custom multi select control for the authors section.
	 *
	 * @since Hestia 1.0
	 */
	class Hestia_Authors_Multiple_Select extends WP_Customize_Control {

		/**
		 * Control type
		 *
		 * @var string
		 */
		public $type = 'multiple-select';

		/**
		 * Repeater name
		 *
		 * @var string
		 */
		public $repeater;

		/**
		 * Default content
		 *
		 * @var array
		 */
		public $default_content;

		/**
		 * Output the control markup.
		 */
		public function render_content() {

			$hestia_repeater_content = get_theme_mod( $this->repeater, $this->default_content );

			if ( ! empty( $hestia_repeater_content ) ) : ?>
				<label>

					<span class="customize-control-title"><?php echo esc_html( $this->label ); ?></span>
					<span class="description customize-control-description"><?php echo wp_kses_post( $this->description ); ?></span>
					<select <?php $this->link(); ?> multiple="multiple" style="width: 100%; height: 100%;" class="repeater-multiselect-team">

						<?php $hestia_repeater_content_decoded = json_decode( $hestia_repeater_content );

						foreach ( $hestia_repeater_content_decoded as $hestia_repeater_item ) {
							if ( ! empty( $hestia_repeater_item ) ) {
								echo '<option value="' . esc_attr( $hestia_repeater_item->id ) . '">' . esc_html( $hestia_repeater_item->title ) . '</option>';
							}
						}
						?>

					</select>
				</label>

			<?php endif;

		}
	}

	// Add general panel.
	$wp_customize->add_section( 'hestia_blog_general', array(
		'title' => __( 'General Settings', 'hestia' ),
		'panel' => 'hestia_blog_settings',
		'priority' => 10,
	));

	// Sidebar on single post toggle.
	$wp_customize->add_setting( 'hestia_sidebar_on_single_post', array(
		'default' => false,
		'sanitize_callback' => 'hestia_sanitize_checkbox',
	));

	$wp_customize->add_control( 'hestia_sidebar_on_single_post',array(
		'label' => __( 'Remove Sidebar on Single Posts?','hestia' ),
		'description' => __( 'If enabled, the sidebar will be removed from single posts.', 'hestia' ),
		'section' => 'hestia_blog_general',
		'priority' => 1,
		'type' => 'checkbox',
	));

	// Alternative Blog Layout.
	$wp_customize->add_setting( 'hestia_alternative_blog_layout', array(
		'default' => false,
		'sanitize_callback' => 'hestia_sanitize_checkbox',
	));

	$wp_customize->add_control( 'hestia_alternative_blog_layout',array(
		'label' => __( 'Enable Alternative Blog Layout?','hestia' ),
		'description' => __( 'If enabled, the blog page will use the alternative layout.', 'hestia' ),
		'section' => 'hestia_blog_general',
		'priority' => 2,
		'type' => 'checkbox',
	));

	// Add authors on blog page panel.
	$wp_customize->add_section( 'hestia_blog_authors', array(
		'title' => __( 'Authors Section', 'hestia' ),
		'panel' => 'hestia_blog_settings',
		'priority' => 20,
	));

	// Authors on blog multiselect.
	$wp_customize->add_setting( 'hestia_authors_on_blog', array(
		'default' => '0',
	));

	$wp_customize->add_control(	new Hestia_Authors_Multiple_Select( $wp_customize,	'hestia_authors_on_blog',
		array(
			'description'   => __( 'Select the team members to appear at the bottom of the blog archive pages. Hold down <b>control / cmd</b> key to select multiple members.', 'hestia' ),
			'label'         => __( 'Team members to appear on blog page', 'hestia' ),
			'section'       => 'hestia_blog_authors',
			'type'          => 'multiple-select',
			'repeater'      => 'hestia_team_content',
			'priority'      => 1,
			'default_content' => json_encode( array(
					array(
						'image_url' => get_template_directory_uri() . '/assets/img/1.jpg',
						'title' => __( 'Anakin Skywalker', 'hestia' ),
						'subtitle' => __( 'Former Jedi', 'hestia' ),
						'text' => __( 'Once a heroic Jedi Knight, Darth Vader was seduced by the dark side of the Force, became a Sith Lord, and led the Empire’s eradication of the Jedi Order.', 'hestia' ),
						'id' => 'customizer_repeater_56d7ea7f40c56',
						'social_repeater' => json_encode( array(
							array(
								'id' => 'customizer-repeater-social-repeater-57fb908674e06',
								'link' => 'facebook.com',
								'icon' => 'fa-facebook',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb9148530fc',
								'link' => 'twitter.com',
								'icon' => 'fa-twitter',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb9150e1e89',
								'link' => 'linkedin.com',
								'icon' => 'fa-linkedin',
							),
						) ),
					),
					array(
						'image_url' => get_template_directory_uri() . '/assets/img/2.jpg',
						'title' => __( 'Obi-Wan Kenobi', 'hestia' ),
						'subtitle' => __( 'Jedi Trainer', 'hestia' ),
						'text' => __( 'A legendary Jedi Master, Obi-Wan Kenobi was a noble man and gifted in the ways of the Force. He trained Anakin and Luke Skywalker as a mentor.', 'hestia' ),
						'id' => 'customizer_repeater_56d7ea7f40c66',
						'social_repeater' => json_encode( array(
							array(
								'id' => 'customizer-repeater-social-repeater-57fb9155a1072',
								'link' => 'facebook.com',
								'icon' => 'fa-facebook',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb9160ab683',
								'link' => 'twitter.com',
								'icon' => 'fa-twitter',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb916ddffc9',
								'link' => 'linkedin.com',
								'icon' => 'fa-linkedin',
							),
						) ),
					),
					array(
						'image_url' => get_template_directory_uri() . '/assets/img/3.jpg',
						'title' => __( 'Luke Skywalker', 'hestia' ),
						'subtitle' => __( 'Jedi', 'hestia' ),
						'text' => __( 'Luke Skywalker was a Tatooine farmboy who rose from humble beginnings to become one of the greatest Jedi the galaxy has ever known.', 'hestia' ),
						'id' => 'customizer_repeater_56d7ea7f40c76',
						'social_repeater' => json_encode( array(
							array(
								'id' => 'customizer-repeater-social-repeater-57fb917e4c69e',
								'link' => 'facebook.com',
								'icon' => 'fa-facebook',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb91830825c',
								'link' => 'twitter.com',
								'icon' => 'fa-twitter',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb918d65f2e',
								'link' => 'linkedin.com',
								'icon' => 'fa-linkedin',
							),
						) ),
					),
					array(
						'image_url' => get_template_directory_uri() . '/assets/img/4.jpg',
						'title' => __( 'Leia Organa', 'hestia' ),
						'subtitle' => __( 'Rebel Leader', 'hestia' ),
						'text' => __( 'Princess Leia Organa was one of the Rebel Alliance’s greatest leaders, fearless on the battlefield and dedicated to ending the tyranny of the Empire.', 'hestia' ),
						'id' => 'customizer_repeater_56d7ea7f40c86',
						'social_repeater' => json_encode( array(
							array(
								'id' => 'customizer-repeater-social-repeater-57fb925cedcb2',
								'link' => 'facebook.com',
								'icon' => 'fa-facebook',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb92615f030',
								'link' => 'twitter.com',
								'icon' => 'fa-twitter',
							),
							array(
								'id' => 'customizer-repeater-social-repeater-57fb9266c223a',
								'link' => 'linkedin.com',
								'icon' => 'fa-linkedin',
							),
						) ),
					),
				)
			),
		)
	) );

	// Background image for authors section on blog.
	$wp_customize->add_setting( 'hestia_authors_on_blog_background', array(
		'default' => get_template_directory_uri() . '/assets/img/header.jpg',
		'sanitize_callback' => 'esc_url_raw',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hestia_authors_on_blog_background', array(
		'label' => __( 'Background Image', 'hestia' ),
		'section' => 'hestia_blog_authors',
		'priority' => 2,
	)));
}

add_action( 'customize_register', 'hestia_blog_settings_customize_register' );
