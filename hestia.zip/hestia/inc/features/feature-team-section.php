<?php
/**
 * Customizer functionality for the Team section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

// Load Customizer repeater control.
require_once( trailingslashit( get_template_directory() ) . '/inc/customizer-repeater/functions.php' );

/**
 * Hook controls for Team section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_team_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'hestia_team', array(
		'title' => __( 'Team', 'hestia' ),
		'panel' => 'hestia_frontpage_sections',
		'priority' => apply_filters( 'hestia_section_priority', 30, 'hestia_team' ),
	));

	$wp_customize->add_setting( 'hestia_team_title', array(
		'default' => __( 'Meet our team', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_team_title', array(
		'label' => __( 'Section Title', 'hestia' ),
		'section' => 'hestia_team',
		'priority' => 5,
	));

	$wp_customize->add_setting( 'hestia_team_subtitle', array(
		'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_team_subtitle', array(
		'label' => __( 'Section Subtitle', 'hestia' ),
		'section' => 'hestia_team',
		'priority' => 10,
	));

	$default_socials = json_encode(
		array(
			array(
				'link' => '#',
				'icon' => 'fa-facebook',
			),
			array(
				'link' => '#',
				'icon' => 'fa-twitter',
			),
			array(
				'link' => '#',
				'icon' => 'fa-linkedin',
			),
		)
	);

	$wp_customize->add_setting( 'hestia_team_content', array(
		'sanitize_callback' => 'hestia_repeater_sanitize',
		'default' => json_encode( array(
			 array(
				'image_url' => get_template_directory_uri() . '/assets/img/1.jpg',
				'title' => __( 'Anakin Skywalker', 'hestia' ),
				'subtitle' => __( 'Former Jedi', 'hestia' ),
				'text' => __( 'Once a heroic Jedi Knight, Darth Vader was seduced by the dark side of the Force, became a Sith Lord, and led the Empire’s eradication of the Jedi Order.', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40c56',
				'social_repeater' => json_encode( array(
					array(
						'id' => 'customizer-repeater-social-repeater-57fb908674e06',
						'link' => 'facebook.com',
						'icon' => 'fa-facebook',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb9148530fc',
						'link' => 'twitter.com',
						'icon' => 'fa-twitter',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb9150e1e89',
						'link' => 'linkedin.com',
						'icon' => 'fa-linkedin',
					),
				) ),
			),
			array(
				'image_url' => get_template_directory_uri() . '/assets/img/2.jpg',
				'title' => __( 'Obi-Wan Kenobi', 'hestia' ),
				'subtitle' => __( 'Jedi Trainer', 'hestia' ),
				'text' => __( 'A legendary Jedi Master, Obi-Wan Kenobi was a noble man and gifted in the ways of the Force. He trained Anakin and Luke Skywalker as a mentor.', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40c66',
				'social_repeater' => json_encode( array(
					array(
						'id' => 'customizer-repeater-social-repeater-57fb9155a1072',
						'link' => 'facebook.com',
						'icon' => 'fa-facebook',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb9160ab683',
						'link' => 'twitter.com',
						'icon' => 'fa-twitter',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb916ddffc9',
						'link' => 'linkedin.com',
						'icon' => 'fa-linkedin',
					),
				) ),
			),
		   	array(
				'image_url' => get_template_directory_uri() . '/assets/img/3.jpg',
				'title' => __( 'Luke Skywalker', 'hestia' ),
				'subtitle' => __( 'Jedi', 'hestia' ),
				'text' => __( 'Luke Skywalker was a Tatooine farmboy who rose from humble beginnings to become one of the greatest Jedi the galaxy has ever known.', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40c76',
				'social_repeater' => json_encode( array(
					array(
						'id' => 'customizer-repeater-social-repeater-57fb917e4c69e',
						'link' => 'facebook.com',
						'icon' => 'fa-facebook',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb91830825c',
						'link' => 'twitter.com',
						'icon' => 'fa-twitter',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb918d65f2e',
						'link' => 'linkedin.com',
						'icon' => 'fa-linkedin',
					),
				) ),
			),
		   	array(
				'image_url' => get_template_directory_uri() . '/assets/img/4.jpg',
				'title' => __( 'Leia Organa', 'hestia' ),
				'subtitle' => __( 'Rebel Leader', 'hestia' ),
				'text' => __( 'Princess Leia Organa was one of the Rebel Alliance’s greatest leaders, fearless on the battlefield and dedicated to ending the tyranny of the Empire.', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40c86',
				'social_repeater' => json_encode( array(
					array(
						'id' => 'customizer-repeater-social-repeater-57fb925cedcb2',
						'link' => 'facebook.com',
						'icon' => 'fa-facebook',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb92615f030',
						'link' => 'twitter.com',
						'icon' => 'fa-twitter',
					),
					array(
						'id' => 'customizer-repeater-social-repeater-57fb9266c223a',
						'link' => 'linkedin.com',
						'icon' => 'fa-linkedin',
					),
				) ),
			),
		)),
	));

	$wp_customize->add_control( new Hestia_Repeater( $wp_customize, 'hestia_team_content', array(
		'label'   => __( 'Team Content','hestia' ),
		'section' => 'hestia_team',
		'priority' => 15,
		'customizer_repeater_image_control' => true,
		'customizer_repeater_title_control' => true,
		'customizer_repeater_subtitle_control' => true,
		'customizer_repeater_text_control' => true,
		'customizer_repeater_link_control' => true,
		'customizer_repeater_repeater_control' => true,
	)));

}

add_action( 'customize_register', 'hestia_team_customize_register' );
