<?php
/**
 * Customizer functionality for the Testimonials section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

// Load Customizer repeater control.
require_once( trailingslashit( get_template_directory() ) . '/inc/customizer-repeater/functions.php' );

/**
 * Hook controls for Testimonials section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_testimonials_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'hestia_testimonials', array(
		'title' => __( 'Testimonials', 'hestia' ),
		'panel' => 'hestia_frontpage_sections',
		'priority' => apply_filters( 'hestia_section_priority', 40, 'hestia_testimonials' ),
	));

	$wp_customize->add_setting( 'hestia_testimonials_title', array(
		'default' => __( 'What clients say', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_testimonials_title', array(
		'label' => __( 'Section Title', 'hestia' ),
		'section' => 'hestia_testimonials',
		'priority' => 5,
	));

	$wp_customize->add_setting( 'hestia_testimonials_subtitle', array(
		'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_testimonials_subtitle', array(
		'label' => __( 'Section Subtitle', 'hestia' ),
		'section' => 'hestia_testimonials',
		'priority' => 10,
	));

	$wp_customize->add_setting( 'hestia_testimonials_content', array(
		'sanitize_callback' => 'hestia_repeater_sanitize',
		'default' => json_encode( array(
			 array(
				'image_url' => get_template_directory_uri() . '/assets/img/1.jpg',
				'title' => __( 'Lord Vader', 'hestia' ),
				'subtitle' => __( 'Dark Lord', 'hestia' ),
				'text' => __( '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40d56',
			),
			array(
				'image_url' => get_template_directory_uri() . '/assets/img/2.jpg',
				'title' => __( 'Kylo Ren', 'hestia' ),
				'subtitle' => __( 'Wanna Be', 'hestia' ),
				'text' => __( '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40d66',
			),
		   	array(
				'image_url' => get_template_directory_uri() . '/assets/img/3.jpg',
				'title' => __( 'Sidious', 'hestia' ),
				'subtitle' => __( 'Sith Lord', 'hestia' ),
				'text' => __( '"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua."', 'hestia' ),
				'id' => 'customizer_repeater_56d7ea7f40d66',
			),
		)),
	));

	$wp_customize->add_control( new Hestia_Repeater( $wp_customize, 'hestia_testimonials_content', array(
		'label'   => __( 'Testimonials Content','hestia' ),
		'section' => 'hestia_testimonials',
		'priority' => 15,
		'customizer_repeater_image_control' => true,
		'customizer_repeater_title_control' => true,
		'customizer_repeater_subtitle_control' => true,
		'customizer_repeater_text_control' => true,
		'customizer_repeater_link_control' => true,
	)));

}

add_action( 'customize_register', 'hestia_testimonials_customize_register' );
