<?php
/**
 * Customizer functionality for the Footer credits.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Hook controls for General section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_general_footer_customize_register( $wp_customize ) {

	$wp_customize->add_setting( 'hestia_general_credits', array(
		'default' => __( '<a href="https://themeisle.com/themes/hestia/" target="_blank" rel="nofollow">Hestia</a> | Powered by <a href="https://wordpress.org/" target="_blank" rel="nofollow">WordPress</a>', 'hestia' ),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_general_credits', array(
		'label' => __( 'Footer Credits', 'hestia' ),
		'section' => 'hestia_general',
		'priority' => 10,
		'type' => 'textarea',
	));

}

add_action( 'customize_register', 'hestia_general_footer_customize_register' );
