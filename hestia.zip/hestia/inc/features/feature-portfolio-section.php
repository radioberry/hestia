<?php
/**
 * Customizer functionality for the Portfolio section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Hook controls for Portfolio section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_portfolio_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'hestia_portfolio', array(
		'title' => __( 'Portfolio', 'hestia' ),
		'panel' => 'hestia_frontpage_sections',
		'priority' => apply_filters( 'hestia_section_priority', 25, 'hestia_portfolio' ),
		'active_callback' => 'jetpack_portfolio_configured_callback',
	));

	$wp_customize->add_setting( 'hestia_portfolio_title', array(
		'default' => __( 'Portfolio', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_portfolio_title', array(
		'label' => __( 'Section Title', 'hestia' ),
		'section' => 'hestia_portfolio',
		'priority' => 5,
	));

	$wp_customize->add_setting( 'hestia_portfolio_subtitle', array(
		'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_portfolio_subtitle', array(
		'label' => __( 'Section Subtitle', 'hestia' ),
		'section' => 'hestia_portfolio',
		'priority' => 10,
	));

	$wp_customize->add_setting( 'hestia_portfolio_items', array(
		'default' => 3,
		'sanitize_callback' => 'absint',
	));

	$wp_customize->add_control( 'hestia_portfolio_items', array(
		'label' => __( 'Number of Items', 'hestia' ),
		'section' => 'hestia_portfolio',
		'priority' => 15,
		'type' => 'number',
	));

	$wp_customize->add_setting( 'hestia_portfolio_boxes_type', array(
		'default' => false,
		'sanitize_callback' => 'hestia_sanitize_checkbox',
	));

	$wp_customize->add_control( 'hestia_portfolio_boxes_type', array(
		'label' => __( 'Enable big boxes?', 'hestia' ),
		'section' => 'hestia_portfolio',
		'priority' => 20,
		'type' => 'checkbox',
	));

}

add_action( 'customize_register', 'hestia_portfolio_customize_register' );

/**
 * Callback for Jetpack portfolio customizer controls.
 *
 * @return bool
 */
function jetpack_portfolio_configured_callback() {
	if ( class_exists( 'Jetpack' ) ) {

		if ( Jetpack::is_module_active( 'custom-content-types' ) && ( post_type_exists( 'jetpack-portfolio' ) ) ) {
			return true;
		}
	}
}
