<?php
/**
 * Customizer functionality for the Subscribe section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Hook controls for Subscribe section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_subscribe_customize_register( $wp_customize ) {

	/**
	 * A custom text control for Subscribe info.
	 *
	 * @since Hestia 1.0
	 */
	class Hestia_Subscribe_Info extends WP_Customize_Control {
		/**
		 * Render content for the control.
		 *
		 * @since Hestia 1.0
		 */
		public function render_content() {
			echo __( 'The main content of this section is customizable in: <b>Customize > Widgets > Subscribe Section</b>. There you must add the "SendinBlue Newsletter." But first you will need to install <a href="https://wordpress.org/plugins/mailin/" target="_blank">SendinBlue plugin</a>.','hestia' );
			echo '<br/><br/>';
			echo __( 'After installing the plugin, you need to navigate to <b>Sendinblue > Home</b>, and configure the plugin.','hestia' );
			echo '<br/><br/>';
			echo __( 'And then you need to navigate to its Settings, and use the following in Subscription form:','hestia' );
			echo '<br/><br/>';
			echo '<textarea style="width:100%;height:180px;font-size:12px;" readonly="">';
		?>
<div class="col-sm-8">
	<div class="input-group">
		<span class="input-group-addon"><i class="fa fa-envelope"></i></span>
		<input type="email" class="sib-email-area form-control" name="email" required="required">
	</div>
</div>
<div class="col-sm-4">
	<input type="submit" class="btn btn-primary btn-block sib-default-btn" name="submit" value="Subscribe">
</div>
		<?php
			echo '</textarea>';
		}
	}

	$wp_customize->add_section( 'hestia_subscribe', array(
		'title' => __( 'Subscribe', 'hestia' ),
		'panel' => 'hestia_frontpage_sections',
		'priority' => apply_filters( 'hestia_section_priority', 45, 'hestia_subscribe' ),
	));

	$wp_customize->add_setting( 'hestia_subscribe_background', array(
		'default' => get_template_directory_uri() . '/assets/img/about.jpg',
		'sanitize_callback' => 'esc_url_raw',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hestia_subscribe_background', array(
		'label' => __( 'Background Image', 'hestia' ),
		'section' => 'hestia_subscribe',
		'priority' => 5,
	)));

	$wp_customize->add_setting( 'hestia_subscribe_title', array(
		'default' => __( 'Subscribe to our Newsletter', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_subscribe_title', array(
		'label' => __( 'Section Title', 'hestia' ),
		'section' => 'hestia_subscribe',
		'priority' => 10,
	));

	$wp_customize->add_setting( 'hestia_subscribe_subtitle', array(
		'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_subscribe_subtitle', array(
		'label' => __( 'Section Subtitle', 'hestia' ),
		'section' => 'hestia_subscribe',
		'priority' => 15,
	));

	$wp_customize->add_setting( 'hestia_subscribe_info', array(
		'sanitize_callback' => 'sanitize_text_field',
	));

	$wp_customize->add_control( new Hestia_Subscribe_Info( $wp_customize, 'hestia_subscribe_info', array(
		'label' => __( 'Instructions', 'hestia' ),
		'section' => 'hestia_subscribe',
		'priority' => 20,
	)));

}

add_action( 'customize_register', 'hestia_subscribe_customize_register' );
