<?php
/**
 * Customizer functionality for the About section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

/**
 * Hook controls for About section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_about_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'hestia_about', array(
		'title' => __( 'About', 'hestia' ),
		'panel' => 'hestia_frontpage_sections',
		'priority' => apply_filters( 'hestia_section_priority', 15, 'hestia_about' ),
	));

	$wp_customize->add_setting( 'hestia_about_title', array(
		'default' => __( 'Who are we', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_about_title', array(
		'label' => __( 'Section Title', 'hestia' ),
		'section' => 'hestia_about',
		'priority' => 5,
	));

	$wp_customize->add_setting( 'hestia_about_subtitle', array(
		'default' => __( 'The story that made us who we are', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_about_subtitle', array(
		'label' => __( 'Section Subtitle', 'hestia' ),
		'section' => 'hestia_about',
		'priority' => 10,
	));

	$wp_customize->add_setting( 'hestia_about_content', array(
		'default' => __( 'Ideate integrate food-truck agile ideate thinker-maker-doer user story intuitive hacker integrate workflow Steve Jobs. Steve Jobs pair programming food-truck big data long shadow SpaceTeam agile agile affordances. User centered design food-truck experiential minimum viable product human-centered design prototype viral quantitative vs. qualitative.', 'hestia' ),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_about_content', array(
		'label' => __( 'Content', 'hestia' ),
		'section' => 'hestia_about',
		'priority' => 15,
		'type' => 'textarea',
	));

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'hestia_about_content', array(
			'selector' => '.about .text-area .about-content',
			'settings' => 'hestia_about_content',
			'render_callback' => 'hestia_about_content_selective_refresh_render_callback',
		));
	}

	$wp_customize->add_setting( 'hestia_about_image', array(
		'default' => get_template_directory_uri() . '/assets/img/about.png',
		'sanitize_callback' => 'esc_url_raw',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'hestia_about_image', array(
		'label' => __( 'Image', 'hestia' ),
		'section' => 'hestia_about',
		'priority' => 20,
	)));

	// Background image for about section.
	$wp_customize->add_setting( 'hestia_about_background', array(
		'default' => get_template_directory_uri() . '/assets/img/contact.jpg',
		'sanitize_callback' => 'esc_url_raw',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'hestia_about_background', array(
		'label' => __( 'Background Image', 'hestia' ),
		'section' => 'hestia_about',
		'priority' => 30,
	)));

}

add_action( 'customize_register', 'hestia_about_customize_register' );

/**
 * Render callback for about section content selective refresh
 *
 * @return mixed
 */
function hestia_about_content_selective_refresh_render_callback() {
	return get_theme_mod( 'hestia_about_content' );
}
