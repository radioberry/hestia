<?php
/**
 * Customizer functionality for the Pricing section.
 *
 * @package WordPress
 * @subpackage Hestia
 * @since Hestia 1.0
 */

if ( ! function_exists( 'hestia_pricing_features' ) ) :
	/**
	 * Sanitize pricing features.
	 *
	 * @since Hestia 1.0
	 */
	function hestia_pricing_features( $value ) {
		$features = explode( '\n', str_replace( '\r', '', wp_kses_post( force_balance_tags( $value ) ) ) );
		return $features;
	}
endif;

/**
 * Hook controls for Pricing section to Customizer.
 *
 * @since Hestia 1.0
 */
function hestia_pricing_customize_register( $wp_customize ) {

	$wp_customize->add_section( 'hestia_pricing', array(
		'title' => __( 'Pricing', 'hestia' ),
		'panel' => 'hestia_frontpage_sections',
		'priority' => apply_filters( 'hestia_section_priority', 35, 'hestia_pricing' ),
	));

	$wp_customize->add_setting( 'hestia_pricing_title', array(
		'default' => __( 'Choose a plan for your next project', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_title', array(
		'label' => __( 'Section Title', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 5,
	));

	$wp_customize->add_setting( 'hestia_pricing_subtitle', array(
		'default' => __( 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_subtitle', array(
		'label' => __( 'Section Subtitle', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 10,
	));

	$wp_customize->add_setting( 'hestia_pricing_table_one_title', array(
		'default' => __( 'Basic Package', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_one_title', array(
		'label' => __( 'Pricing Table One: Title', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 15,
	));

	$wp_customize->add_setting( 'hestia_pricing_table_one_price', array(
		'default' => __( '<small>$</small>0', 'hestia' ),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_one_price', array(
		'label' => __( 'Pricing Table One: Price', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 20,
	));

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'hestia_pricing_table_one_price', array(
			'selector' => '.pricing .col-md-6:nth-child(1) .card-pricing .card-title',
			'settings' => 'hestia_pricing_table_one_price',
			'render_callback' => 'hestia_selective_refresh_table_one_price_render_callback',
		));
	} else {
		$wp_customize->get_setting( 'hestia_pricing_table_one_price' )->transport = 'refresh';
	}

	$wp_customize->add_setting( 'hestia_pricing_table_one_features', array(
		'sanitize_callback' => 'hestia_pricing_features',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_one_features', array(
		'label' => __( 'Pricing Table One: Features', 'hestia' ),
		'description' => __( 'Seperate your features by adding \n between lines.', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 25,
		'type' => 'textarea',
	));

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'hestia_pricing_table_one_features', array(
			'selector' => '.pricing .col-md-6:nth-child(1) .card-pricing ul',
			'settings' => 'hestia_pricing_table_one_features',
			'render_callback' => 'hestia_selective_refresh_table_one_features_render_callback',
		));
	} else {
		$wp_customize->get_setting( 'hestia_pricing_table_one_features' )->transport = 'refresh';
	}

	$wp_customize->add_setting( 'hestia_pricing_table_one_link', array(
		'default' => __( '#', 'hestia' ),
		'sanitize_callback' => 'esc_url',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_one_link', array(
		'label' => __( 'Pricing Table One: Link', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 30,
	));

	$wp_customize->add_setting( 'hestia_pricing_table_one_text', array(
		'default' => __( 'Free Download', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_one_text', array(
		'label' => __( 'Pricing Table One: Text', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 35,
	));

	$wp_customize->add_setting( 'hestia_pricing_table_two_title', array(
		'default' => __( 'Premium Package', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_two_title', array(
		'label' => __( 'Pricing Table Two: Title', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 40,
	));

	$wp_customize->add_setting( 'hestia_pricing_table_two_price', array(
		'default' => __( '<small>$</small>49', 'hestia' ),
		'sanitize_callback' => 'wp_kses_post',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_two_price', array(
		'label' => __( 'Pricing Table Two: Price', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 45,
	));

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'hestia_pricing_table_two_price', array(
			'selector' => '.pricing .col-md-6:nth-child(2) .card-pricing .card-title',
			'settings' => 'hestia_pricing_table_two_price',
			'render_callback' => 'hestia_selective_refresh_table_two_price_render_callback',
		));
	} else {
		$wp_customize->get_setting( 'hestia_pricing_table_two_price' )->transport = 'refresh';
	}

	$wp_customize->add_setting( 'hestia_pricing_table_two_features', array(
		'sanitize_callback' => 'hestia_pricing_features',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_two_features', array(
		'label' => __( 'Pricing Table Two: Features', 'hestia' ),
		'description' => __( 'Seperate your features by adding \n between lines.', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 50,
		'type' => 'textarea',
	));

	if ( isset( $wp_customize->selective_refresh ) ) {
		$wp_customize->selective_refresh->add_partial( 'hestia_pricing_table_two_features', array(
			'selector' => '.pricing .col-md-6:nth-child(2) .card-pricing ul',
			'settings' => 'hestia_pricing_table_two_features',
			'render_callback' => 'hestia_selective_refresh_table_two_features_render_callback',
		));
	} else {
		$wp_customize->get_setting( 'hestia_pricing_table_two_features' )->transport = 'refresh';
	}

	$wp_customize->add_setting( 'hestia_pricing_table_two_link', array(
		'default' => __( '#', 'hestia' ),
		'sanitize_callback' => 'esc_url',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_two_link', array(
		'label' => __( 'Pricing Table Two: Link', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 55,
	));

	$wp_customize->add_setting( 'hestia_pricing_table_two_text', array(
		'default' => __( 'Order Now', 'hestia' ),
		'sanitize_callback' => 'sanitize_text_field',
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'hestia_pricing_table_two_text', array(
		'label' => __( 'Pricing Table Two: Text', 'hestia' ),
		'section' => 'hestia_pricing',
		'priority' => 60,
	));

}

add_action( 'customize_register', 'hestia_pricing_customize_register' );

/**
 * Render callback for pricing section first table price selective refresh
 *
 * @return mixed
 */
function hestia_selective_refresh_table_one_price_render_callback() {
	return get_theme_mod( 'hestia_pricing_table_one_price' );
}

/**
 * Render callback for pricing section first table features selective refresh
 *
 * @return mixed
 */
function hestia_selective_refresh_table_one_features_render_callback() {
	$hestia_pricing_table_one_features = get_theme_mod( 'hestia_pricing_table_one_features' );
	foreach ( $hestia_pricing_table_one_features as $feature ) :
		?>
		<li><?php echo wp_kses_post( $feature );?></li>
		<?php
	endforeach;
}

/**
 * Render callback for pricing section second table price selective refresh
 *
 * @return mixed
 */
function hestia_selective_refresh_table_two_price_render_callback() {
	return get_theme_mod( 'hestia_pricing_table_two_price' );
}


/**
 * Render callback for pricing section second table features selective refresh
 *
 * @return mixed
 */
function hestia_selective_refresh_table_two_features_render_callback() {
	$hestia_pricing_table_two_features = get_theme_mod( 'hestia_pricing_table_two_features' );
	foreach ( $hestia_pricing_table_two_features as $feature ) :
		?>
		<li><?php echo wp_kses_post( $feature );?></li>
		<?php
	endforeach;
}
