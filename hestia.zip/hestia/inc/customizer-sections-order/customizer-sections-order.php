<?php
/**
 * Customizer sections ordem main file
 *
 * @package Hestia
 */

/**
 * Function to enqueue sections order main script.
 */
function hestia_sections_customizer_script() {
	wp_enqueue_script( 'customizer-sections-order-script', get_template_directory_uri() . '/inc/customizer-sections-order/js/customizer-sections-order.js', array( 'jquery', 'jquery-ui-sortable' ), '1.0.0', true );
	$control_settings = array(
		'sections_container' => '#accordion-panel-hestia_frontpage_sections ul',
		'blocked_items' => '#accordion-section-hestia_slider',
		'saved_data_input' => '#customize-control-sections_order input',
	);
	wp_localize_script( 'customizer-sections-order-script', 'control_settings', $control_settings );
	wp_enqueue_style( 'customizer-sections-order-style', get_template_directory_uri() . '/inc/customizer-sections-order/css/customizer-sections-order-style.css', array( 'dashicons' ) );
}
add_action( 'customize_controls_enqueue_scripts', 'hestia_sections_customizer_script' );


/**
 * Function to enqueue live preview
 */
function hestia_sections_live_preview() {
	wp_enqueue_script( 'hestia_sections_live_preview', get_template_directory_uri() . '/inc/customizer-sections-order/js/customizer-sections-live-preview.js', array( 'jquery', 'customize-preview' ), '', true );
}
add_action( 'customize_preview_init', 'hestia_sections_live_preview' );


/**
 * Register input for sections order.
 *
 * @param object $wp_customize Customizer object.
 */
function hestia_section_control_register( $wp_customize ) {

	$wp_customize->add_setting( 'sections_order', array(
		'transport' => 'postMessage',
	));

	$wp_customize->add_control( 'sections_order', array(
		'section'   => 'hestia_general',
		'type'  => 'hidden',
		'priority'  => 80,
	));

}
add_action( 'customize_register', 'hestia_section_control_register' );


/**
 * Function for returning section priority
 *
 * @param int    $value Default priority.
 * @param string $key Section id.
 *
 * @return int
 */
function hestia_get_section_priority( $value, $key = '' ) {
	$orders = get_theme_mod( 'sections_order' );
	if ( ! empty( $orders ) ) {
		$json = json_decode( $orders );
		if ( isset( $json->$key ) ) {
			return $json->$key;
		}
	}
	return $value;
}
add_filter( 'hestia_section_priority', 'hestia_get_section_priority', 10, 2 );
