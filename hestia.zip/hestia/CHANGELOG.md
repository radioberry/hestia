
### 1.0.2 - 20/10/2016
**Changes:** 
- Added support for Jetpack portfolio
- Improved WooCommerce implementation
- Section Order
- Fixed small layout issues

### 1.0.1 - 18/10/2016
**Changes:** 
- Alternative blog template
- Improved layout style
- Added option for sidebar on blog posts
- Optimize the main menu
- Improved WooCommerce layout
- Added grunt + fix all grunt errors

### 1.0.0 - 03/10/2016
**Changes:** 
- First version

