# Hestia #
Theme description goes here.

# Installation #
1. After downloading the zip file, go to Appearance > Themes and click on the *Install Themes* tab.
2. Click on the *Upload* link.
3. Upload the zip file that you downloaded and click *Install Now*.
4. Click *Activate* to use the theme you just installed.

# Copyright, License & Other info #

License: [GNU General Public License v2.0] or later (license.txt file)
Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public License. See License URI in style.css for further details.

## Libraries ##

wp_bootstrap_navwalker, https://github.com/twittem/wp-bootstrap-navwalker
Copyright 2014 Twitter, Edward McIntyre, GPL-2.0+, http://www.gnu.org/licenses/gpl-2.0.txt

Bootstrap, http://getbootstrap.com/
Copyright 2011-2015 Twitter, Inc, MIT License, http://www.opensource.org/licenses/MIT

FontAwesome, http://fontawesome.io/
Copyright 2015, Dave Gandy,
Font Awesome licensed under SIL OFL 1.1, http://scripts.sil.org/OFL
Code licensed under MIT License, http://www.opensource.org/licenses/MIT
Documentation licensed under CC BY 3.0, http://creativecommons.org/licenses/by/3.0/

jquery.matchHeight.js, http://brm.io/jquery-match-height/
Copyright 2014, liabru, MIT License, http://www.opensource.org/licenses/MIT

## Images ##

Credits for image goes here.

# Changelog #

## Version 1.0 ##

- Initial Release.