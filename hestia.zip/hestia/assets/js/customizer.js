( function( $ ) {

	// Site Identity > Site Title
	wp.customize( 'blogname', function( value ) {
		value.bind( function( newval ) {
			$( '.navbar .navbar-brand h1').text( newval );
		} );
	} );

	// Site Identity > Site Description
	wp.customize( 'blogdescription', function( value ) {
		value.bind( function( newval ) {
			$( '.blog .page-header .title' ).text( newval );
		} );
	} );

	// Appearance Settings > General Settings > Boxed Layout
	wp.customize( 'hestia_general_layout', function( value ) {
		value.bind( function() {
			if( $( '.main' ).hasClass( 'main-raised' ) ) {
				$( '.main' ).removeClass( 'main-raised' );
			} else {
				$( '.main' ).addClass( 'main-raised' );
			}
		} );
	} );

	// Appearance Settings > General Settings > Footer Credits
	wp.customize( 'hestia_general_credits', function( value ) {
		value.bind( function( newval ) {
			$( '.footer-black .copyright' ).html( newval );
		} );
	} );

	// Frontpage Sections > Features  > Title
	wp.customize( 'hestia_features_title', function( value ) {
		value.bind( function( newval ) {
			$( '.features .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Features  > Subtitle
	wp.customize( 'hestia_features_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.features .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > About  > Title
	wp.customize( 'hestia_about_title', function( value ) {
		value.bind( function( newval ) {
            var element = $( '.about .title' );
            var aboutImage = $( '.about .media-area' );
            var textArea = $( '.about .text-area' );
            if ( ( newval === '' ) && ($( '.about .description' ).text()==='' ) && ($( '.about .about-content' ).text()==='' ) ) {
                textArea.css( 'display', 'none' );
                element.css( 'display', 'none' );
                aboutImage.removeClass( 'col-md-7 col-md-offset-1' );
                aboutImage.addClass( 'col-md-12' );
            } else {
                element.text( newval );
                textArea.css( 'display', 'block' );
                element.css( 'display', 'block' );
                aboutImage.removeClass( 'col-md-12' );
                aboutImage.addClass( 'col-md-7 col-md-offset-1' );
            }
		} );
	} );

	// Frontpage Sections > About  > Subtitle
	wp.customize( 'hestia_about_subtitle', function( value ) {
		value.bind( function( newval ) {
		    var element = $( '.about .description' );
		    var aboutImage = $( '.about .media-area' );
            var textArea = $( '.about .text-area' );
            if ( ( newval === '' ) && ($( '.about .title' ).text()==='' ) && ($( '.about .about-content' ).text()==='' ) ) {
                textArea.css( 'display', 'none' );
                element.css( 'display', 'none' );
                aboutImage.removeClass( 'col-md-7 col-md-offset-1' );
                aboutImage.addClass( 'col-md-12' );
            } else {
                element.text( newval );
                textArea.css( 'display', 'block' );
                element.css( 'display', 'block' );
                aboutImage.removeClass( 'col-md-12' );
                aboutImage.addClass( 'col-md-7 col-md-offset-1' );
            }
		} );
	} );

	// Frontpage Sections > About  > Content
	wp.customize( 'hestia_about_content', function( value ) {
		value.bind( function( newval ) {
            var element = $( '.about .about-content' );
            var aboutImage = $( '.about .media-area' );
            var textArea = $( '.about .text-area' );
            if ( ( newval === '' ) && ($( '.about .title' ).text()==='' ) && ($( '.about .description' ).text()==='' ) ) {
                textArea.css( 'display', 'none' );
                element.css( 'display', 'none' );
                aboutImage.removeClass( 'col-md-7 col-md-offset-1' );
                aboutImage.addClass( 'col-md-12' );
			} else {
                element.text( newval );
                textArea.css( 'display', 'block' );
                element.css( 'display', 'block' );
                aboutImage.removeClass( 'col-md-12' );
                aboutImage.addClass( 'col-md-7 col-md-offset-1' );
			}
		} );
	} );

	// Frontpage Sections > About  > Image
	wp.customize( 'hestia_about_image', function( value ) {
		value.bind( function( newval ) {
			var aboutImage = $( '.about .media-area' );
			var textArea = $( '.about .text-area' );
			if ( newval === '' ) {
				aboutImage.css( 'display', 'none' );
				textArea.removeClass( 'col-md-4' );
				textArea.addClass( 'col-md-12' );
			} else {
				aboutImage.removeClass( 'customizer-hidden' );
				$( '.about .media-area img' ).attr( 'src', newval );
				aboutImage.css( 'display', 'block' );
				textArea.removeClass( 'col-md-12' );
				textArea.addClass( 'col-md-4' );
			}
		} );
	} );

	// Frontpage Sections > About > Background
	wp.customize( 'hestia_about_background', function( value ) {
		value.bind( function( newval ) {
			$( '.about' ).css( 'background-image', 'url(' +newval+ ')' );
			if( newval === '' ) {
				$( '.about' ).removeClass('section-image');
			} else {
				$( '.about' ).addClass('section-image');
			}
		} );
	} );

	// Frontpage Sections > Shop  > Title
	wp.customize( 'hestia_shop_title', function( value ) {
		value.bind( function( newval ) {
			$( '.products .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Shop  > Subtitle
	wp.customize( 'hestia_shop_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.products .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Portfolio  > Title
	wp.customize( 'hestia_portfolio_title', function( value ) {
		value.bind( function( newval ) {
			$( '.work .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Portfolio  > Subtitle
	wp.customize( 'hestia_portfolio_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.work .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Team  > Title
	wp.customize( 'hestia_team_title', function( value ) {
		value.bind( function( newval ) {
			$( '.team .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Team  > Subtitle
	wp.customize( 'hestia_team_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.team .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Pricing  > Title
	wp.customize( 'hestia_pricing_title', function( value ) {
		value.bind( function( newval ) {
			$( '.pricing .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Pricing  > Subtitle
	wp.customize( 'hestia_pricing_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.pricing .text-gray' ).text( newval );
		} );
	} );

	// Frontpage Sections > Pricing  > Pricing Table One: Title
	wp.customize( 'hestia_pricing_table_one_title', function( value ) {
		value.bind( function( newval ) {
			$( '.pricing .col-md-6:nth-child(1) .card-pricing .category' ).text( newval );
		} );
	} );

	// Frontpage Sections > Pricing  > Pricing Table One: Text
	wp.customize( 'hestia_pricing_table_one_text', function( value ) {
		value.bind( function( newval ) {
			$( '.pricing .col-md-6:nth-child(1) .card-pricing .btn' ).text( newval );
		} );
	} );

	// Frontpage Sections > Pricing  > Pricing Table Two: Title
	wp.customize( 'hestia_pricing_table_two_title', function( value ) {
		value.bind( function( newval ) {
			$( '.pricing .col-md-6:nth-child(2) .card-pricing .category' ).text( newval );
		} );
	} );

	// Frontpage Sections > Pricing  > Pricing Table Two: Text
	wp.customize( 'hestia_pricing_table_two_text', function( value ) {
		value.bind( function( newval ) {
			$( '.pricing .col-md-6:nth-child(2) .card-pricing .btn' ).text( newval );
		} );
	} );

	// Frontpage Sections > Testimonials  > Title
	wp.customize( 'hestia_testimonials_title', function( value ) {
		value.bind( function( newval ) {
			$( '.testimonials .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Testimonials  > Subtitle
	wp.customize( 'hestia_testimonials_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.testimonials .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Subscribe  > Background
	wp.customize( 'hestia_subscribe_background', function( value ) {
		value.bind( function( newval ) {
			$( '.subscribe-line' ).css( 'background-image', 'url(' +newval+ ')' );
		} );
	} );

	// Frontpage Sections > Subscribe  > Title
	wp.customize( 'hestia_subscribe_title', function( value ) {
		value.bind( function( newval ) {
			$( '.subscribe-line .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Subscribe  > Subtitle
	wp.customize( 'hestia_subscribe_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.subscribe-line .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Blog  > Title
	wp.customize( 'hestia_blog_title', function( value ) {
		value.bind( function( newval ) {
			$( '.blogs .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Blog  > Subtitle
	wp.customize( 'hestia_blog_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.blogs .description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Contact  > Background
	wp.customize( 'hestia_contact_background', function( value ) {
		value.bind( function( newval ) {
			$( '.contactus' ).css( 'background-image', 'url(' +newval+ ')' );
		} );
	} );

	// Frontpage Sections > Contact  > Title
	wp.customize( 'hestia_contact_title', function( value ) {
		value.bind( function( newval ) {
			$( '.contactus .title' ).text( newval );
		} );
	} );

	// Frontpage Sections > Contact  > Subtitle
	wp.customize( 'hestia_contact_subtitle', function( value ) {
		value.bind( function( newval ) {
			$( '.contactus h5.description' ).text( newval );
		} );
	} );

	// Frontpage Sections > Contact  > Form Title
	wp.customize( 'hestia_contact_area_title', function( value ) {
		value.bind( function( newval ) {
			$( '.contactus .card-contact .card-title' ).text( newval );
		} );
	} );

    // Blog Settiungs > Authors Section > Background
    wp.customize( 'hestia_authors_on_blog_background', function( value ) {
        value.bind( function( newval ) {
            $( '#authors-on-blog.authors-on-blog' ).css( 'background-image', 'url(' +newval+ ')' );
        } );
    } );
} )( jQuery );
